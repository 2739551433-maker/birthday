<template>
  <router-view />
</template>

<script setup>
// 不需要额外内容
</script>
